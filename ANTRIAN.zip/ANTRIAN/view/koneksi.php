<?php
$host       = "localhost";
$user       = "root";
$password   = "";
$database   = "antrian";
$connect    = mysqli_connect($host, $user, $password, $database)
?>