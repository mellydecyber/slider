<?php 
	if (!isset($_SESSION["loket_client"])) 
	{
		$_SESSION["loket_client"] = 0;
	}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
	    <!-- <meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <meta name="description" content="">
	    <meta name="author" content="">
	    <title>Client : Queue</title>
	    <link href="../assert/css/bootstrap.min.css" rel="stylesheet">
	    <link href="../assert/css/jumbotron-narrow.css" rel="stylesheet">
		<script src="../assert/js/jquery.min.js"></script> -->
	</head>
	<body onkeydown="myFunction(event)">
    <!-- <div class="container" id="tampil" style="display: none;"> -->
    <div class="container" id="tampil" >
        
        <div class="jumbotron1">
        <h1 class="counter">
        	0
        </h1>
       
      	</div>
		  <form>
    		<div class="jumbotron">
	        <h1 class="next">
	        </h1>
	      	</div>
    		</form>
		  <input type="hidden" id="idloket">
      	<footer class="footer">
        <p>&copy; RS PHCM <?php echo date("Y");?></p>
      	</footer>
    </div>
  	</body>
  	<script type="text/javascript">
	
	$("document").ready(function()
	{
		var data = {"loket": '1' };
		$.ajax({
			type: "POST",
			dataType: "json",
			url: "../apps/last_stage.php",//request
			data: data,
			success: function(data) {
				$(".jumbotron1 h1").html(data["next"]);
			}
		});
		$.post( "../apps/admin_getway.php", function( data ) {
			$(".next").html(data['next']);
		},"json");
		

	});

	
	var timerId_adik=0;
		// ADIK_ADUDU
		function adik_adudu(loket, counter){
			timerId_adik = setInterval(function() {
				 $.post("../apps/daemon_cek.php", { loket : loket, counter : counter }, function(msg){
					if(msg.huft == 2){
						$(".next_queue").show();
					}
				},'JSON');
			}, 1000);
		}

		// TRY CALL
		var timerId=0;
		// ADUDU
		function adudu(loket, counter){
			timerId = setInterval(function() {
				 $.post("../apps/daemon_try_cek.php", { loket : loket, counter : counter }, function(msg){
					if(msg.huft == 2){
						$(".try_queue").show();
					}
				},'JSON');
			}, 1000);
		 }

	function myFunction(e){
	
		/* tombol F11 */
		if(e.keyCode == 49) {

			$("#idloket").val("1");

	    	//set seassion or save
	    	var data = {"loket": '1'};
			$.ajax({
				type: "POST",
				dataType: "json",
				url: "../apps/set_loket.php",//request
				data: data,
				success: function(data) {
					$(".jumbotron1 h1").html(data["next"]);
				}
			});
	  
	   
		var loket = '1';
			if (loket==0) {
				$(".peringatan").show();
			}else{
				var data = {"loket" : loket};
				$.ajax({
					type: "POST",
					dataType: "json",
					url: "../apps/daemon.php",//request
					data: data,
					success: function(data) {
						$(".jumbotron1 h1").html(data["next"]);
						if (data["idle"]=="TRUE") {
							$(".next_queue").hide();
							clearInterval(timerId_adik);
							adik_adudu(loket, data["next"]);
						}
					}
				});
				return false;
				
			}
		}else if(e.keyCode == 50) {
			$("#idloket").val("2");
	    	//set seassion or save
	    	var data = {"loket": '2'};
			$.ajax({
				type: "POST",
				dataType: "json",
				url: "../apps/set_loket.php",//request
				data: data,
				success: function(data) {
					$(".jumbotron1 h1").html(data["next"]);
				}
			});
	   
	   
		var loket = '2';
			if (loket==0) {
				$(".peringatan").show();
			}else{
				var data = {"loket" : loket};
				$.ajax({
					type: "POST",
					dataType: "json",
					url: "../apps/daemon.php",//request
					data: data,
					success: function(data) {
						$(".jumbotron1 h1").html(data["next"]);
						if (data["idle"]=="TRUE") {
							$(".next_queue").hide();
							clearInterval(timerId_adik);
							adik_adudu(loket, data["next"]);
						}
					}
				});
				return false;
			}
		}
		else if(e.keyCode == 51) {
			$("#idloket").val("3");
	    	//set seassion or save
	    	var data = {"loket": '3'};
			$.ajax({
				type: "POST",
				dataType: "json",
				url: "../apps/set_loket.php",//request
				data: data,
				success: function(data) {
					$(".jumbotron1 h1").html(data["next"]);
				}
			});
	
	   
		var loket = '3';
			if (loket==0) {
				$(".peringatan").show();
			}else{
				var data = {"loket" : loket};
				$.ajax({
					type: "POST",
					dataType: "json",
					url: "../apps/daemon.php",//request
					data: data,
					success: function(data) {
						$(".jumbotron1 h1").html(data["next"]);
						if (data["idle"]=="TRUE") {
							$(".next_queue").hide();
							clearInterval(timerId_adik);
							adik_adudu(loket, data["next"]);
						}
					}
				});
				return false;
			}
		}

			if(e.keyCode == 48) {
	
			var loket = $('#idloket').val();
			if (loket==0) {
	    		$(".peringatan").show();
			}else{
				var counter = $(".counter").text();
				$.post("../apps/daemon_try.php", { loket : loket, counter : counter }, function(msg){
					if(msg.huft == 0){
						$(".try_queue").hide();
						clearInterval(timerId);
						adudu(loket, counter);
					}
				},'JSON'); //request
				return false;
			}
		}
		if(e.keyCode == 13) {
			
		
	
	    // RESET 
			var next_current = $(".next").text();
			$.post( "../apps/admin_getway.php", {"next_current": next_current}, function( data ) {
				$(".next").html(data['next']);
			},"json");
		}
		
	}
	</script>
</html>

