<?php
	$mysqli->close();