# Aplikasi Antrian
Aplikasi ini hanya sederhana yang dibuat untuk proses registrasi mahasiswa baru di Institut Teknologi Sumatra. Teridiri dari 3 interface yaitu :
* Client
![Client](assert/img/client.png)
* Monitoring
![Monitoring](assert/img/monitoring.png)
* Admin
![Admin](assert/img/admin.png)

## Requirement
Install
* apache 2.x.x
* PHP 5.x.x (with pdo_sqlite,json)
* Mysql 5.x.x >
* Jquery